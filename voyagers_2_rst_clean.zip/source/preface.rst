Preface
=======

For there is nothing hidden except to be revealed...