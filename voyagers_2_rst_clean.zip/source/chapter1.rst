Chapter 1: The Secrets of Amenti
================================

Origins of Tara...