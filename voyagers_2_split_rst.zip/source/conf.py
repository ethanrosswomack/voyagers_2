
project = 'Voyagers II'
author = 'Ashayana Deane'
release = 'Full'

extensions = []
templates_path = ['_templates']
exclude_patterns = []

html_theme = 'furo'
html_static_path = ['_static']
