Chapter 2: The Second Seeding
=============================

Sirius B and Melchizedek...